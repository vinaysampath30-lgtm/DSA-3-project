# Clinical Record Linkage & Care Coordination Platform

A modern academic health-tech prototype for synthetic clinical-record linkage, patient 360 views, care coordination, and interactive algorithm demonstrations.

## What is included

- Responsive React dashboard with record metrics, trend charts, alerts, work queue, patient search, and activity log
- Record Linkage Engine and Duplicate Detection review flow, including an explicit confirmation step before merging
- Patient directory, referral pipeline, care-task board, analytics, and audit history
- Interactive API-driven KMP, Z-algorithm, and Rabin–Karp demos, plus network-flow and set-cover examples
- Express REST API, JWT demo login, Zod login validation, synthetic seed data, and a PostgreSQL Prisma schema
- Visible synthetic-data notice throughout the application

## Run locally

1. Copy `.env.example` to `.env` and replace `JWT_SECRET`.
2. Install packages with `npm install`.
3. Start both applications with `npm run dev`.
4. Open `http://localhost:5173`.

The frontend runs on port 5173 and proxies API calls to the Express service on port 4000.

## Demo API

`POST /api/auth/login` accepts any valid email and non-empty password for demonstration. An email containing `doctor` or `analyst` selects that synthetic role; other accounts use Care Coordinator.

Key routes include `/api/dashboard`, `/api/patients`, `/api/records/matches`, `/api/tasks`, `/api/referrals`, and the algorithm endpoints under `/api/algorithms`.

## Database

The included Prisma schema models users, patients, patient records, hospitals, referrals, care tasks, appointments, clinical entities, record matches, algorithm executions, and audit logs. After configuring PostgreSQL, run:

```powershell
npx prisma db push --schema server/prisma/schema.prisma
npm run seed
```

All data presented by the application is fictional and intended only for educational demonstrations.
